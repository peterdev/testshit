#include <stdio.h>

int
main(){
printf("----  Hello, I am a LIFEBOX core system!  ----\n");
return 0;
} 
